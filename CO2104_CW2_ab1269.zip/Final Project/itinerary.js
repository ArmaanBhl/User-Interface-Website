document.addEventListener('DOMContentLoaded', function () {
  const itineraryContainer = document.getElementById('itinerary');
  const numDaysInput = document.getElementById('numDays');
  const applyBtn = document.getElementById('applyBtn');
  const saveBtn = document.getElementById('saveBtn'); 

const allPlans = {
  museum: [
    { text: 'Visit the Science and Industry Museum.', imgSrc: 'images/science and industry museum.jpg', alt: 'Science and Industry Museum building exterior' },
    { text: 'Tour the Manchester Art Gallery.', imgSrc: 'images/art gallery.webp', alt: 'Manchester Art Gallery entrance' },
    { text: 'Explore the People’s History Museum.', imgSrc: 'images/PeoplesHistoryMuseum.jpeg', alt: 'People’s History Museum building' },
    { text: 'Walk around the National Football Museum.', imgSrc: 'images/football museum.jpg', alt: 'National Football Museum glass tower' },
    { text: 'See the exhibits at The Whitworth.', imgSrc: 'images/whitworth.jpg', alt: 'The Whitworth Gallery exterior' }
  ],
  park: [
    { text: 'Stroll through Heaton Park.', imgSrc: 'images/heaton-park.jpg', alt: 'Green space and trees at Heaton Park' },
    { text: 'Visit Fletcher Moss Botanical Garden.', imgSrc: 'images/fletchermoss.jpg', alt: 'Path through Fletcher Moss Botanical Garden' },
    { text: 'Relax at Whitworth Park.', imgSrc: 'images/whitworth park.jpg', alt: 'Open field in Whitworth Park' },
    { text: 'Go boating at Sale Water Park.', imgSrc: 'images/sale water park.jpg', alt: 'Lake view at Sale Water Park with boats' },
    { text: 'Explore Platt Fields Park.', imgSrc: 'images/platt park.jpg', alt: 'Trees and open grass in Platt Fields Park' },
    { text: 'Have a picnic at Alexandra Park.', imgSrc: 'images/alexandra.jpg', alt: 'Pathway and greenery in Alexandra Park' }
  ],
  food: [
    { text: 'Eat at Mackie Mayor.', imgSrc: 'images/mackie mayor.jpg', alt: 'Food hall inside Mackie Mayor' },
    { text: 'Try curry at Curry Mile.', imgSrc: 'images/curry mile.webp', alt: 'Restaurants along Manchester’s Curry Mile' },
    { text: 'Grab lunch at Rudy’s Pizza.', imgSrc: 'images/rudy pizza.jpg', alt: 'Fresh pizza served at Rudy’s Pizza' },
    { text: 'Enjoy fine dining at 20 Stories.', imgSrc: 'images/20 stories.jpg', alt: 'Outdoor terrace at 20 Stories restaurant' },
    { text: 'Try vegan dishes at V-Rev.', imgSrc: 'images/v-rev.png', alt: 'Colorful vegan dish from V-Rev' }
  ],
  nightlife: [
    { text: 'Dance at The Warehouse Project.', imgSrc: 'images/warehouse project.png', alt: 'Crowd at The Warehouse Project' },
    { text: 'Cocktails at Cloud 23.', imgSrc: 'images/cloud 23.webp', alt: 'Skyline view from Cloud 23 bar' },
    { text: 'Bavarian Beer at Albert Schloss', imgSrc: 'images/albert scholls.jpg', alt: 'Interior of Albert Schloss with guests' },
    { text: 'Love Indie music. Deaf Institute is the place to be!', imgSrc: 'images/deaf institute.jpeg', alt: 'Stage and lighting inside Deaf Institute' },
    { text: 'Hidden. Multi-Room warehouse club.', imgSrc: 'images/hidden.jpg', alt: 'Dark dance floor at Hidden nightclub' }
  ],
  sports: [
    { text: 'Tour Old Trafford Stadium.', imgSrc: 'images/old trafford.jpg', alt: 'Old Trafford Stadium exterior' },
    { text: 'Watch a football match.', imgSrc: 'images/man utd.avif', alt: 'Manchester United players during a match' },
    { text: 'Tour the Eithad Stadium.', imgSrc: 'images/etihad.jpg', alt: 'Etihad Stadium pitch view' },
    { text: 'Tour the Salford Community Stadium.', imgSrc: 'images/Salford stadium.jpg', alt: 'Seats at Salford Community Stadium' },
    { text: 'Chill Factore: Experience Indoor Skiing and Snowboarding', imgSrc: 'images/chill factore.jpg', alt: 'Ski slopes inside Chill Factore' }
  ],
  shopping: [
    { text: 'Shop at Manchester Arndale.', imgSrc: 'images/arndale.jpg', alt: 'Inside Manchester Arndale shopping centre' },
    { text: 'Explore the Trafford Centre.', imgSrc: 'images/trafford centre.jpg', alt: 'Decorative interior of Trafford Centre' },
    { text: 'Shop at the Exchange Square', imgSrc: 'images/exchnage square.jpg', alt: 'People shopping at Exchange Square' },
    { text: 'Explore Market Street.]', imgSrc: 'images/market street.jpg', alt: 'Crowded Market Street in Manchester' },
    { text: 'Explore Afflecks Palace', imgSrc: 'images/afflecks.webp', alt: 'Exterior of Afflecks with murals' }
  ]
};


  const usedIndices = {
    museum: [], park: [], food: [], nightlife: [], sports: [], shopping: []
  };

  function getNextPlan(type) {
    const plans = allPlans[type];
    if (!plans || plans.length === 0) return null;

    const used = usedIndices[type];
    if (used.length === plans.length) usedIndices[type] = [];

    const remaining = plans.map((_, i) => i).filter(i => !used.includes(i));
    const nextIndex = remaining[Math.floor(Math.random() * remaining.length)];
    usedIndices[type].push(nextIndex);

    return plans[nextIndex];
  }

  function createItineraryItem(text, imgSrc) {
    const item = document.createElement('div');
    item.className = 'itinerary-item';

    const img = document.createElement('img');
    img.alt = 'Image';
    if (imgSrc) {
      img.src = imgSrc;
      img.style.width = '200px';
      img.style.height = 'auto';
    } else {
      img.style.display = 'none';
    }

    const desc = document.createElement('p');
    desc.innerText = text;

    const controls = document.createElement('div');
    controls.className = 'controls';

    const removeBtn = document.createElement('button');
    removeBtn.innerText = 'REMOVE';
    removeBtn.onclick = () => item.remove();

    const addBtn = document.createElement('button');
    addBtn.innerText = 'ADD';

    const dropdown = document.createElement('select');
    dropdown.style.display = 'none';
    ['museum', 'park', 'food', 'nightlife', 'sports', 'shopping'].forEach(cat => {
      const option = document.createElement('option');
      option.value = cat;
      option.text = cat.charAt(0).toUpperCase() + cat.slice(1);
      dropdown.appendChild(option);
    });

    const confirmAdd = document.createElement('button');
    confirmAdd.innerText = '➕';
    confirmAdd.style.display = 'none';
    confirmAdd.style.backgroundColor = 'white';

    addBtn.onclick = () => {
      dropdown.style.display = 'inline-block';
      confirmAdd.style.display = 'inline-block';
    };

    confirmAdd.onclick = () => {
      const selectedType = dropdown.value;
      const newPlan = getNextPlan(selectedType);
      if (newPlan) {
        const newItem = createItineraryItem(newPlan.text, newPlan.imgSrc, selectedType);
        item.insertAdjacentElement('afterend', newItem);
      } else {
        alert('No more activities left in this category.');
      }
      dropdown.style.display = 'none';
      confirmAdd.style.display = 'none';
    };

    controls.appendChild(removeBtn);
    controls.appendChild(addBtn);
    controls.appendChild(dropdown);
    controls.appendChild(confirmAdd);

    item.appendChild(img);
    item.appendChild(desc);
    item.appendChild(controls);

    return item;
  }

  applyBtn.addEventListener('click', function () {
    itineraryContainer.innerHTML = '';

    const interestCheckboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    const selectedInterests = Array.from(interestCheckboxes).map(cb => cb.value);
    const numDays = parseInt(numDaysInput.value) || 1;

    for (let i = 0; i < numDays; i++) {
      selectedInterests.forEach(type => {
        const plan = getNextPlan(type);
        if (plan) {
          itineraryContainer.appendChild(
            createItineraryItem(`${plan.text} (Day ${i + 1})`, plan.imgSrc, type)
          );
        }
      });
    }
  });

  saveBtn.addEventListener('click', () => {
    const items = document.querySelectorAll('.itinerary-item');
    let itineraryText = '';

    items.forEach((item, index) => {
      const desc = item.querySelector('p')?.innerText || '';
      itineraryText += `Activity ${index + 1}: ${desc}\n`;
    });

    const blob = new Blob([itineraryText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = 'itinerary.txt';
    a.click();

    URL.revokeObjectURL(url);
  });
});
