document.addEventListener("DOMContentLoaded", () => {
  let slideIndex = 0;
  const slides = document.querySelectorAll('.slide-image');

  function showNextSlide() {
    slides.forEach((slide) => slide.classList.remove('active'));
    slides[slideIndex].classList.add('active');
    slideIndex = (slideIndex + 1) % slides.length;
  }

  // Show the first slide initially
  showNextSlide();

  // Rotate slides every 4 seconds
  setInterval(showNextSlide, 4000);
});
