const form = document.querySelector('form');

form.addEventListener('submit', function(event) {
  event.preventDefault();

  const name = form.querySelector('input[type="text"]').value;
  const email = form.querySelector('input[type="email"]').value;
  const password = form.querySelector('input[type="password"]').value;

  // Save user data to localStorage
  const user = { name, email, password };
  localStorage.setItem('user', JSON.stringify(user));

  alert('Sign-up successful! Please log in.');
  window.location.href = 'login.html'; // Redirect to login page
});
